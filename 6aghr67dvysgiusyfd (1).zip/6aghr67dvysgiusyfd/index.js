const { Client, GatewayIntentBits } = require('discord.js');
const { SlashCommandBuilder } = require('@discordjs/builders');
const { REST } = require('@discordjs/rest');
const { token, clientId } = require('./config.json');
const { Routes } = require('discord-api-types/v9');

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

let userPoints = {}; // لتخزين النقاط للمستخدمين

// الأوامر بالبرفكس
client.on('messageCreate', async message => {
  if (message.channel.id === '1330305069203066934') {
    if (message.content.startsWith('-تسجيل دخول')) {
      const loginRole = message.guild.roles.cache.get('1330305068288835647'); // رتبة تسجيل الدخول
      const logoutRole = message.guild.roles.cache.get('1330305068288835646'); // رتبة تسجيل الخروج
      if (loginRole && logoutRole) {
        await message.member.roles.add(loginRole);
        await message.member.roles.remove(logoutRole);
        // إضافة نقطة عند تسجيل الدخول
        const userId = message.author.id;
        if (!userPoints[userId]) userPoints[userId] = 0;
        userPoints[userId]++;
        message.reply('تم إضافة رتبة تسجيل الدخول! لديك الآن ' + userPoints[userId] + ' نقاط.');
      }
    }

    if (message.content.startsWith('-تسجيل خروج')) {
      const loginRole = message.guild.roles.cache.get('1330305068288835647'); // رتبة تسجيل الدخول
      const logoutRole = message.guild.roles.cache.get('1330305068288835646'); // رتبة تسجيل الخروج
      if (loginRole && logoutRole) {
        await message.member.roles.add(logoutRole);
        await message.member.roles.remove(loginRole);
        message.reply('تم إضافة رتبة تسجيل الخروج!');
      }
    }
  }

  if (message.content.startsWith('-نقاط')) {
    const user = message.mentions.users.first();
    if (user) {
      message.reply(`${user.tag} لديه ${userPoints[user.id] || 0} نقاط.`);
    } else {
      message.reply('يرجى ذكر المستخدم.');
    }
  }

  if (message.content.startsWith('-نقاطي')) {
    const userId = message.author.id;
    message.reply(`أنت لديك ${userPoints[userId] || 0} نقاط.`);
  }
});

// الأوامر السلاش
const commands = [
  new SlashCommandBuilder().setName('set_playing_status').setDescription('تعيين حالة البوت مثل online, idle, dnd, invisible.')
    .addStringOption(option => option.setName('status').setDescription('حالة البوت').setRequired(true)
      .addChoices(
        { name: 'online', value: 'online' },
        { name: 'idle', value: 'idle' },
        { name: 'dnd', value: 'dnd' },
        { name: 'invisible', value: 'invisible' }
      )),
  new SlashCommandBuilder().setName('send_message_to_all').setDescription('إرسال رسالة لجميع المستخدمين في الخاص.')
    .addStringOption(option => option.setName('message').setDescription('أدخل الرسالة التي تريد إرسالها').setRequired(true)),
  new SlashCommandBuilder().setName('set_playing').setDescription('تعيين حالة Playing للبوت.')
    .addStringOption(option => option.setName('status').setDescription('حالة playing').setRequired(true))
];

const rest = new REST({ version: '9' }).setToken(token);

client.once('ready', () => {
  console.log('البوت الآن جاهز!');

  // تأكد من تحديث الأوامر عند تشغيل البوت
  (async () => {
    try {
      console.log('بدأ تحديث الأوامر في السيرفرات.');
      await rest.put(
        Routes.applicationCommands(clientId),  // نشر الأوامر على مستوى البوت
        { body: commands.map(command => command.toJSON()) },
      );
      console.log('تم تحديث الأوامر بنجاح.');
    } catch (error) {
      console.error(error);
    }
  })();
});

// التعامل مع الأوامر السلاش
client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  const { commandName } = interaction;

  if (commandName === 'set_playing_status') {
    const status = interaction.options.getString('status');
    try {
      client.user.setStatus(status);
      interaction.reply(`تم تعيين حالة البوت إلى ${status}!`);
    } catch (error) {
      interaction.reply('حدث خطأ أثناء تعيين الحالة.');
    }
  }

  if (commandName === 'set_playing') {
    const status = interaction.options.getString('status');
    try {
      client.user.setActivity(status, { type: 'PLAYING' });
      interaction.reply(`تم تعيين حالة Playing للبوت إلى ${status}`);
    } catch (error) {
      interaction.reply('حدث خطأ أثناء تعيين الحالة.');
    }
  }

  if (commandName === 'send_message_to_all') {
    const messageContent = interaction.options.getString('message');
    const members = await interaction.guild.members.fetch();
    members.forEach(member => {
      if (!member.user.bot) { // تجاهل البوتات
        member.send(messageContent).catch(() => {});
      }
    });
    interaction.reply('تم إرسال الرسالة للجميع في الخاص!');
  }
});

client.login(token);
